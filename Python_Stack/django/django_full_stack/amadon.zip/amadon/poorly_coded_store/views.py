from django.shortcuts import render,redirect
from .models import Order, Product

def index(request):
    if 'items' not in request.session:
        request.session['items']=0
    if 'price' not in request.session:
        request.session['price']=0
    if 'total_price' not in request.session:
        request.session['total_price']=0
    context = {
        "all_products": Product.objects.all()
    }
    return render(request, "store/index.html", context)

def checkout(request):
    item_id = Product.objects.get(id=request.POST['id'])
    print("Print id",item_id)
    price = item_id.price
    request.session['items'] += int(request.POST["quantity"])
    request.session['price'] = int(request.POST["quantity"]) * float(price)
    request.session['total_price'] += int(request.POST["quantity"]) * float(price)
    print("Charging credit card...")
    # Order.objects.create(quantity_ordered=quantity_from_form, total_price=total_charge)
    return redirect ('/process_checkout')

def process_checkout(request):
    context = {
        "quantity_from_form":request.session['items'],
        "total_charge":request.session['total_price'],
        "order_price":request.session['price']

    }
    return render(request, "store/checkout.html",context)

def clear(request):
    request.session['items'] = 0
    request.session['price']=0
    request.session['total_price']=0
    return redirect('/')
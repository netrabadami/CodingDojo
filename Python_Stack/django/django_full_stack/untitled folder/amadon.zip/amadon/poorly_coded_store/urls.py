from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('checkout', views.checkout),
    path('process_checkout',views.process_checkout),
    path('clear',views.clear)
]

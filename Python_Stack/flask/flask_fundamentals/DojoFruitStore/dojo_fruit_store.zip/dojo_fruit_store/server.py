from flask import Flask, render_template, request, redirect
import datetime
app = Flask(__name__)  
today = datetime.datetime.now()

@app.route('/')         
def index():
    return render_template("index.html")

@app.route('/checkout', methods=['POST'])         
def checkout():
    print(request.form)
    firstName = request.form['first_name']
    lastName = request.form['last_name']
    studentId = request.form['student_id']
    strawberry = request.form['strawberry']
    raspberry = request.form['raspberry']
    apple = request.form['apple']
    total = int(strawberry) + int(raspberry)+int(apple)
    now = today.strftime("%B %d, %Y %I:%M:%S %p")
    print("Charging "+firstName+" for "+str(total)+" fruits")
    return render_template("checkout.html",firstName=firstName,lastName=lastName,studentId = studentId,strawberry=strawberry,raspberry=raspberry,apple=apple,total=total,now=now)

@app.route('/fruits')         
def fruits():
    return render_template("fruits.html")

if __name__=="__main__":   
    app.run(debug=True)    
from flask import Flask,render_template,request,redirect
app = Flask(__name__,template_folder='template')


@app.route('/')
def user():
	return render_template("dojosurvey.html")

@app.route('/survey', methods=['POST'])
def submitSurvey():
	yourName = request.form['yourName']
	dojoLocation = request.form['dojoLocation']
	comments = request.form['comment']
	return render_template("displaysurvey.html", yourName=yourName, dojoLocation=dojoLocation, comments=comments)

if __name__ == "__main__":
	app.run(debug=True)